Facebook-PHP-CodeIgniter
========================

This repo is based on Facebook PHP SDK (v.3.2.2)
Link: https://github.com/facebook/facebook-php-sdk


Usage
-----

The [config file][CONFIG] is a good place to start. All you need to do is 
enter application id and secret.

    $config['appId']   = 'APP_ID_HERE';
    $config['secret']  = 'SECRET_HERE';

Thats it!

Read the controller and view file to understand the working.

[CONFIG]: https://github.com/puneetkay/Facebook-PHP-CodeIgniter/blob/master/config/facebook.php
