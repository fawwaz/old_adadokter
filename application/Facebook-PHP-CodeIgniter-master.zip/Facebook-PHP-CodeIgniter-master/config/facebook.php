<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = 'APP_ID_HERE';
$config['secret']  = 'SECRET_HERE';

?>
