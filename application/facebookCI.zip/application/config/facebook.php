<?php
	$config['appId'] 			= '';
	$config['secret'] 			= '';
?>