<?php
/**
 * twconnect library configuration
 */

$config = array(
  'consumer_key'    => 'YOUR APP CONSUMER KEY',
  'consumer_secret' => 'YOUR APP CONSUMER SECRET',
  'oauth_callback'      => '/twtest/callback' // Default callback application path
);

?>